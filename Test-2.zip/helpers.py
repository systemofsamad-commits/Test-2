import re
import logging
from typing import Optional
from config import Config

config = Config()
logger = logging.getLogger(__name__)


# ✅ ИСПРАВЛЕНО: Используем singleton вместо создания нового экземпляра
def get_db():
    """
    Получить единственный экземпляр БД

    Returns:
        Database: Экземпляр базы данных
    """
    from database import get_db as _get_db
    return _get_db()


def is_admin(user_id: int) -> bool:
    """
    Проверяет, является ли пользователь администратором

    Args:
        user_id: Telegram ID пользователя

    Returns:
        bool: True если администратор

    Example:
        >>> if is_admin(message.from_user.id):
        ...     await show_admin_panel()
    """
    try:
        db = get_db()
        return db.admins.is_admin(user_id)
    except Exception as e:
        logger.error(f"Error checking admin status for user {user_id}: {e}")
        # Fallback на статический список из config
        return user_id in config.ADMIN_IDS


def extract_id(text: str) -> Optional[int]:
    """
    Извлечение ID из текста

    Поддерживает форматы:
    - "Студент (123)" -> 123
    - "123" -> 123
    - "#123" -> 123

    Args:
        text: Текст для парсинга

    Returns:
        int: Извлеченный ID или None

    Example:
        >>> extract_id("Иван Иванов (42)")
        42
        >>> extract_id("123")
        123
    """
    try:
        # Сначала ищем в скобках
        match = re.search(r'\((\d+)\)', text)
        if match:
            return int(match.group(1))

        # Затем ищем после #
        match = re.search(r'#(\d+)', text)
        if match:
            return int(match.group(1))

        # Если весь текст - число
        if text and text.strip().isdigit():
            return int(text.strip())

        return None
    except Exception as e:
        logger.error(f"Error extracting ID from '{text}': {e}")
        return None


def get_grade_from_progress(progress: float) -> str:
    """
    Получить оценку на основе прогресса

    Args:
        progress: Процент прогресса (0-100)

    Returns:
        str: Буквенная оценка (A-F)

    Example:
        >>> get_grade_from_progress(95)
        'A'
        >>> get_grade_from_progress(75)
        'C'
    """
    for grade, threshold in config.GRADING_SCALE.items():
        if progress >= threshold:
            return grade
    return 'F'


def get_student_by_id(student_id: int):
    """
    Получить студента по ID

    Args:
        student_id: ID студента

    Returns:
        Dict: Данные студента или None

    Example:
        >>> student = get_student_by_id(5)
        >>> print(student['full_name'])
    """
    try:
        db = get_db()
        return db.students.get_by_id(student_id)
    except Exception as e:
        logger.error(f"Error getting student {student_id}: {e}")
        return None


def format_phone(phone: str) -> str:
    """
    Форматировать номер телефона

    Args:
        phone: Телефон в любом формате

    Returns:
        str: Форматированный телефон

    Example:
        >>> format_phone("998901234567")
        '+998 (90) 123-45-67'
    """
    # Убираем все кроме цифр
    digits = re.sub(r'\D', '', phone)

    # Форматируем для Узбекистана
    if digits.startswith('998') and len(digits) == 12:
        return f"+{digits[0:3]} ({digits[3:5]}) {digits[5:8]}-{digits[8:10]}-{digits[10:12]}"

    # Возвращаем как есть если не подходит
    return phone


def format_price(price: int) -> str:
    """
    Форматировать цену

    Args:
        price: Цена в сумах

    Returns:
        str: Форматированная строка

    Example:
        >>> format_price(550000)
        '550 000 сум'
    """
    return f"{price:,}".replace(',', ' ') + ' сум'


def get_status_emoji(status: str) -> str:
    """
    Получить emoji для статуса

    Args:
        status: Код статуса

    Returns:
        str: Emoji
    """
    status_emojis = {
        'active': '✅',
        'trial': '🎯',
        'studying': '📚',
        'frozen': '❄️',
        'waiting_payment': '💰',
        'completed': '🎓'
    }
    return status_emojis.get(status, '📋')


def truncate_text(text: str, max_length: int = 100) -> str:
    """
    Обрезать текст до максимальной длины

    Args:
        text: Исходный текст
        max_length: Максимальная длина

    Returns:
        str: Обрезанный текст с "..."
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."


# ============================================
# ВАЛИДАЦИЯ ДАННЫХ
# ============================================

def validate_phone(phone: str) -> bool:
    """Проверить корректность номера телефона"""
    digits = re.sub(r'\D', '', phone)
    # Узбекистан: 998 + 9 цифр
    return len(digits) >= 9


def validate_email(email: str) -> bool:
    """Проверить корректность email"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_rating(rating: int) -> bool:
    """Проверить корректность рейтинга"""
    return 1 <= rating <= 5