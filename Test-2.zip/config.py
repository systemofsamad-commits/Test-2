import os


class Config:
    # ============================================
    # ОСНОВНЫЕ НАСТРОЙКИ
    # ============================================
    BOT_TOKEN = os.getenv('BOT_TOKEN', '7695101627:AAGmJn1G5GIoqL2ILiGgAtzePOZEsHQjVJ8')
    ADMIN_IDS = [866916345]

    # ✅ КРИТИЧЕСКОЕ ИЗМЕНЕНИЕ: Единая база данных
    DB_NAME = "education_center.db"  # Было: "students.db"

    CHANNEL_ID = -1002906910895

    # ============================================
    # СТАТУСЫ СТУДЕНТОВ (только для отображения)
    # ============================================
    STATUSES = {
        'active': 'Активные',
        'trial': 'Пробный урок',
        'studying': 'Обучаются',
        'frozen': 'Заморожены',
        'waiting_payment': 'Ожидание оплаты',
        'completed': 'Завершили'
    }

    # ❌ УДАЛЕНО: TABLE_NAMES больше не нужны!
    # Раньше было 7 отдельных таблиц, теперь одна с колонкой status_code

    # ============================================
    # КУРСЫ И ЦЕНЫ
    # ============================================
    COURSES = {
        "🇯🇵 Японский язык": {
            "Групповые занятия (80 минут)": "550,000 сум за 12 уроков",
            "Индивидуальное обучение (1 час)": "1,300,000 сум за 12 уроков",
        },
        "🇬🇧 Английский язык": {
            "Групповые занятия (60 минут)": "450,000 сум за 12 уроков",
            "Индивидуальное обучение (1 час)": "1,200,000 сум за 12 уроков"
        }
    }

    SCHEDULES = ["Утренняя группа", "Обеденная группа", "Вечерняя группа"]

    # ============================================
    # МАТЕРИАЛЫ ДЛЯ КУРСОВ
    # ============================================
    MATERIALS = {
        "🇯🇵 Японский язык": {
            "📖 Учебник по хирагане": "https://example.com/hiragana-textbook",
            "🎥 Видео-уроки для начинающих": "https://youtube.com/playlist?list=example",
            "📝 Рабочая тетрадь (PDF)": "https://example.com/workbook.pdf",
            "🗣️ Аудио-диалоги": "https://example.com/audio-lessons"
        },
        "🇬🇧 Английский язык": {
            "📖 Грамматика для начинающих": "https://example.com/english-grammar",
            "🎥 Разговорный английский": "https://youtube.com/playlist?list=english",
            "📝 Тесты и упражнения": "https://example.com/english-exercises.pdf",
            "🎧 Аудиокурс": "https://example.com/audio-course"
        }
    }

    # ============================================
    # ТЕСТЫ/ВИКТОРИНЫ
    # ============================================
    QUIZZES = {
        "🇯🇵 Японский язык": [
            {
                "question": "Как переводится 'こんにちは'?",
                "options": ["Здравствуйте", "До свидания", "Спасибо", "Извините"],
                "answer": 0,
                "explanation": "'こんにちは' - это стандартное японское приветствие, означающее 'Здравствуйте'."
            },
            {
                "question": "Какой символ хираганы означает 'a'?",
                "options": ["あ", "い", "う", "え"],
                "answer": 0,
                "explanation": "Символ 'あ' представляет звук 'a' в японской слоговой азбуке хирагана."
            },
            {
                "question": "Что означает 'ありがとう'?",
                "options": ["Пожалуйста", "Спасибо", "Извините", "Добро пожаловать"],
                "answer": 1,
                "explanation": "'ありがとう' - японское слово для выражения благодарности, 'Спасибо'."
            }
        ],
        "🇬🇧 Английский язык": [
            {
                "question": "What is the past tense of 'go'?",
                "options": ["goed", "went", "gone", "going"],
                "answer": 1,
                "explanation": "The past tense of 'go' is 'went'. Example: 'I went to school yesterday.'"
            },
            {
                "question": "Which word is a pronoun?",
                "options": ["run", "beautiful", "he", "quickly"],
                "answer": 2,
                "explanation": "'He' is a pronoun that replaces a masculine noun."
            },
            {
                "question": "What does 'hello' mean?",
                "options": ["Пока", "Привет", "Спасибо", "Извините"],
                "answer": 1,
                "explanation": "'Hello' is an English greeting meaning 'Привет' or 'Здравствуйте'."
            }
        ]
    }

    # ============================================
    # ДОПОЛНИТЕЛЬНЫЕ НАСТРОЙКИ
    # ============================================
    MAX_REGISTRATIONS = 5
    GRADING_SCALE = {'A': 90, 'B': 80, 'C': 70, 'D': 60, 'F': 0}

    ADMIN_SETTINGS = {
        'max_groups_per_teacher': 3,
        'max_students_per_group': 15,
        'default_lesson_duration': 60
    }

    ENTITY_STATUSES = {
        'active': 'Активен',
        'inactive': 'Неактивен',
        'pending': 'Ожидает',
        'completed': 'Завершен'
    }