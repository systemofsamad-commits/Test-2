import logging
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext

from states.admin_states import AdminStates
from helpers import is_admin, get_db  # ✅ ИЗМЕНЕНО: добавлен get_db
from config import Config

logger = logging.getLogger(__name__)
router = Router(name="admin_status_handlers")  # ✅ ИЗМЕНЕНО: исправлено имя роутера
config = Config()


@router.callback_query(F.data.startswith("admin_quick_"))
async def quick_status_change(callback: CallbackQuery, state: FSMContext):
    """Быстрая смена статуса студента"""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Доступ запрещён")
        return

    try:
        callback_data = callback.data
        logger.info(f"Quick status change data: {callback_data}")

        # Убираем префикс "admin_quick_"
        data_without_prefix = callback_data.replace("admin_quick_", "")

        # Разделяем на части по последнему подчёркиванию
        last_underscore_index = data_without_prefix.rfind('_')
        if last_underscore_index == -1:
            await callback.answer("❌ Ошибка формата данных")
            return

        new_status = data_without_prefix[:last_underscore_index]
        registration_id_str = data_without_prefix[last_underscore_index + 1:]

        try:
            registration_id = int(registration_id_str)
        except ValueError:
            await callback.answer("❌ Неверный ID студента")
            return

        logger.info(f"Changing status for student {registration_id} to {new_status}")

        # ✅ ИЗМЕНЕНО: Используем новый репозиторий
        db = get_db()
        reg = db.registrations.get_by_id(registration_id)

        if not reg:
            await callback.answer("❌ Студент не найден")
            return

        # Сохраняем данные для подтверждения
        await state.update_data(
            registration_id=registration_id,
            new_status=new_status,
            student_name=reg['name'],
            current_status=reg['status_code']
        )

        status_names = {
            'trial': '🟡 Пробный урок',
            'studying': '🔵 Обучаются',
            'frozen': '⚪ Заморожены',
            'waiting_payment': '🟠 Ожидание оплаты',
            'completed': '🟣 Завершили',
            'active': '🟢 Активные'
        }

        current_status_name = config.STATUSES.get(reg['status_code'], reg['status_code'])
        new_status_name = status_names.get(new_status, new_status)

        # Показываем подтверждение
        from keyboards.admin_kb import get_status_change_confirmation_keyboard
        await callback.message.edit_text(
            f"🔄 *Смена статуса студента*\n\n"
            f"👤 *Студент:* {reg['name']}\n"
            f"📞 Телефон: {reg['phone']}\n"
            f"📚 Курс: {reg['course_name']}\n\n"
            f"📊 *Текущий статус:* {current_status_name}\n"
            f"🎯 *Новый статус:* {new_status_name}\n\n"
            f"✅ *Подтвердите изменение статуса:*",
            parse_mode="Markdown",
            reply_markup=get_status_change_confirmation_keyboard(registration_id, new_status, reg['status_code'])
        )

        await callback.answer()

    except Exception as e:
        logger.error(f"Error in quick_status_change: {e}")
        await callback.answer("❌ Произошла ошибка")


@router.callback_query(F.data.startswith("admin_confirm_"))
async def confirm_status_change(callback: CallbackQuery, state: FSMContext):
    """Подтверждение смены статуса"""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Доступ запрещён")
        return

    try:
        # Разбираем данные
        callback_data = callback.data
        logger.info(f"Confirm status change data: {callback_data}")

        # Убираем префикс "admin_confirm_"
        data_without_prefix = callback_data.replace("admin_confirm_", "")

        # Разделяем на части по последнему подчёркиванию
        last_underscore_index = data_without_prefix.rfind('_')
        if last_underscore_index == -1:
            await callback.answer("❌ Ошибка формата данных")
            return

        new_status = data_without_prefix[:last_underscore_index]
        registration_id_str = data_without_prefix[last_underscore_index + 1:]

        try:
            registration_id = int(registration_id_str)
        except ValueError:
            await callback.answer("❌ Неверный ID студента")
            return

        # ✅ ИЗМЕНЕНО: Используем новый репозиторий
        db = get_db()
        success = db.registrations.update_status(registration_id, new_status)

        if success:
            # Получаем обновлённые данные студента
            reg = db.registrations.get_by_id(registration_id)

            status_names = {
                'trial': '🟡 Пробный урок',
                'studying': '🔵 Обучаются',
                'frozen': '⚪ Заморожены',
                'waiting_payment': '🟠 Ожидание оплаты',
                'completed': '🟣 Завершили',
                'active': '🟢 Активные'
            }

            new_status_name = status_names.get(new_status, new_status)

            from keyboards.admin_kb import get_student_actions_keyboard
            await callback.message.edit_text(
                f"✅ *Статус успешно обновлён!*\n\n"
                f"👤 *Студент:* {reg['name']}\n"
                f"📞 Телефон: {reg['phone']}\n"
                f"📚 Курс: {reg['course_name']}\n\n"
                f"🎯 *Новый статус:* {new_status_name}\n\n"
                f"📊 Студент перемещён в соответствующую категорию.",
                parse_mode="Markdown",
                reply_markup=get_student_actions_keyboard(registration_id, new_status, reg['name'])
            )

            logger.info(f"✅ Статус студента {reg['name']} (ID: {registration_id}) изменён на {new_status}")

        else:
            reg = db.registrations.get_by_id(registration_id)
            from keyboards.admin_kb import get_student_actions_keyboard
            await callback.message.edit_text(
                "❌ *Ошибка при обновлении статуса*\n\n"
                "Попробуйте ещё раз или обратитесь к разработчику.",
                parse_mode="Markdown",
                reply_markup=get_student_actions_keyboard(registration_id, reg['status_code'], reg['name'])
            )

    except Exception as e:
        logger.error(f"Error in confirm_status_change: {e}")
        await callback.answer("❌ Произошла ошибка")


@router.callback_query(F.data.startswith("admin_cancel_"))
async def cancel_status_change(callback: CallbackQuery):
    """Отмена смены статуса"""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Доступ запрещён")
        return

    try:
        registration_id = int(callback.data.replace("admin_cancel_", ""))

        # ✅ ИЗМЕНЕНО: Используем новый репозиторий
        db = get_db()
        reg = db.registrations.get_by_id(registration_id)

        if reg:
            from keyboards.admin_kb import get_student_actions_keyboard
            await callback.message.edit_text(
                f"❌ *Смена статуса отменена*\n\n"
                f"👤 *Студент:* {reg['name']}\n"
                f"📊 Статус остался без изменений.",
                parse_mode="Markdown",
                reply_markup=get_student_actions_keyboard(registration_id, reg['status_code'], reg['name'])
            )
        else:
            await callback.answer("❌ Студент не найден")

    except Exception as e:
        logger.error(f"Error in cancel_status_change: {e}")
        await callback.answer("❌ Произошла ошибка")


@router.callback_query(F.data.startswith("admin_back_"))
async def back_to_student(callback: CallbackQuery):
    """Возврат к карточке студента"""
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Доступ запрещён")
        return

    try:
        registration_id = int(callback.data.replace("admin_back_", ""))

        # ✅ ИЗМЕНЕНО: Используем новый репозиторий
        db = get_db()
        reg = db.registrations.get_by_id(registration_id)

        if reg:
            status_text = config.STATUSES.get(reg['status_code'], reg['status_code'])
            info_text = (
                f"📋 *Карточка студента:*\n\n"
                f"👤 Имя: {reg['name']}\n"
                f"📞 Телефон: {reg['phone']}\n"
                f"🎯 Курс: {reg['course_name']}\n"
                f"📊 Статус: {status_text}\n"
                f"🆔 ID: {reg['id']}\n"
            )

            from keyboards.admin_kb import get_student_actions_keyboard
            await callback.message.edit_text(
                info_text,
                parse_mode="Markdown",
                reply_markup=get_student_actions_keyboard(registration_id, reg['status_code'], reg['name'])
            )
        else:
            await callback.answer("❌ Студент не найден")

    except Exception as e:
        logger.error(f"Error in back_to_student: {e}")
        await callback.answer("❌ Произошла ошибка")